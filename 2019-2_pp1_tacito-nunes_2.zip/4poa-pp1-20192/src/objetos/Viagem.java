package objetos;

	public class Viagem implements Comparable<Viagem> {
		
		private String nome;
		private String preco;
		private String origem;
		private String destino;
		private String[] opcionais;
		
		public Viagem(String no, String pr, String or, String de, String[] opc){
			setNome(no);
			setPreco(pr);
			setOrigem(or);
			setDestino(de);
			setOpcionais(opc);
		}

		@Override
		public int compareTo(Viagem outro) {
			return preco.compareTo(outro.preco);
		}
		
		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome.toUpperCase();
		}

		public String getPreco() {
			return preco;
		}

		public void setPreco(String preco) {
			this.preco = preco.toUpperCase();
		}

		public String getOrigem() {
			return origem;
		}

		public void setOrigem(String origem) {
			this.origem= origem.toUpperCase();
		}

		public String getDestino() {
			return destino;
		}

		public void setDestino(String destino) {
			this.destino = destino.toUpperCase();
		}

		public String[] getOpcionais() {
			return opcionais;
		}

		public void setOpcionais(String[] opcionais) {
			this.opcionais = opcionais;
		}
		
	}

