package objetos;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class Escrita {

	static String path = "C:\\4poa\\";
	static String arq = "pp1_tacito-nunes.txt";
	
	public static void escrever(Viagem viagem){

		File diretorio = new File(path);
		
		if (!diretorio.exists()) {
			diretorio.mkdir();
		}
		try {			
			FileWriter fw = new FileWriter(path + arq, true);
			
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(viagem.getNome() + ";" + viagem.getPreco() + ";" + viagem.getOrigem() + ";" + viagem.getDestino() + ";" + Arrays.toString(viagem.getOpcionais()).replace("[", "").replace("]", ""));
			
			bw.newLine();
			
			bw.close();
			fw.close();
			
		} catch(IOException erro){
			erro.printStackTrace();
		}
	}
	
	
}
