package objetos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class Leitura {

	public static LinkedList<Viagem> ler() {

		LinkedList<Viagem> lista = new LinkedList<Viagem>();

		try {
			FileReader fr = new FileReader(Escrita.path + Escrita.arq); 
			
			BufferedReader br = new BufferedReader(fr);
			
			while(br.ready()) {
				String linha = br.readLine();
				
				String[] atr = linha.split(";");
				String[] opcs = atr[4].split(",");
				
				lista.add(new Viagem(atr[0], atr[1], atr[2], atr[3], opcs));
			}
			
			br.close();
			fr.close();
		}
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
		e.printStackTrace();
		}

		return lista;
	}
}
