package servlet;

import objetos.Viagem;
import objetos.Escrita;
import objetos.Leitura;
import java.util.LinkedList;
import java.util.Collections;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Servlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String nome = request.getParameter("nome");
		String preco = request.getParameter("preco");
		String origem = request.getParameter("origem");
		String destino = request.getParameter("destino");

		String[] opc = request.getParameterValues("opcionais");
		
		HttpSession novaSessao = request.getSession();

		Viagem viagem = new Viagem(nome, preco, origem, destino, opc);

		Escrita.escrever(viagem);
		
		LinkedList<Viagem> listagem = Leitura.ler();
		
		Collections.sort(listagem);
		
		novaSessao.setAttribute("lista", listagem);
		
		response.sendRedirect("paginas/retorno.jsp");

	}

}
